(function($){
    $('.datepicker').datepicker();
})(jQuery);